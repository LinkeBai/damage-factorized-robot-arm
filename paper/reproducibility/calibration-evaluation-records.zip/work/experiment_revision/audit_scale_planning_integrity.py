"""Audit complete on-disk cells during a live run, without effect estimates."""
from pathlib import Path
import json,hashlib
import numpy as np
R=Path(__file__).resolve().parents[2];D=R/'runs/ipwm_validation_scale_calibration/planning_confirmation';p=json.loads((D/'protocol.json').read_text());sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
assert sha(R/'work/experiment_revision/confirm_scale_planning.py')==p['script_sha256']
for path,h in p['selection_hashes'].items():assert sha(R/path)==h
refs={};checked=[];pending=[];model_hashes={}
for file in sorted(D.glob('seed*.npz')):
 meta=file.with_suffix('.json')
 if not meta.exists():pending.append(file.name);continue
 d=json.loads(meta.read_text());s,m,l,b=d['seed'],d['method'],d['lock'],d['band']
 assert s in p['seeds'] and m in p['methods'] and l in range(1,6) and b in [0,1]
 family=m if m in ['global','carrier'] else 'ipwm'
 model=R/f'runs/ipwm_validation_scale_calibration/seed{s}/model.pt' if m=='calibrated' else R/f'runs/ipwm_scale_goal_20260911/training/{family}/seed{s}/model.pt'
 if model not in model_hashes:model_hashes[model]=sha(model)
 assert d['model_sha256']==model_hashes[model],file
 with np.load(file) as z:
  assert z['states'].shape==(6,120,14),file
  assert z['goals'].shape==(120,2) and z['choices'].shape==(5,120) and z['commands'].shape==(5,120,5),file
  assert all(np.isfinite(z[k]).all() for k in z.files),file
  assert ((z['choices']>=0)&(z['choices']<128)).all(),file
  assert np.max(np.abs(z['commands'][:,:,l-1]))==0,file
  endpoint=np.linalg.norm(z['states'][-1,:,10:12]-z['goals'],axis=1)
  assert np.allclose(z['endpoint'],endpoint,rtol=1e-6,atol=1e-9),file
  assert np.array_equal(z['success'],endpoint<.03),file
  key=(l,b)
  initial=z['states'][0].copy();goals=z['goals'].copy()
  if key in refs:
   assert np.array_equal(initial,refs[key][0]) and np.array_equal(goals,refs[key][1]),file
  else:refs[key]=(initial,goals)
 checked.append(file.name)
out={'scope':'Available paired cell integrity only; no performance estimates','checked_cells':len(checked),'expected_cells':240,'pending_sidecars':pending,'checks':['frozen script and selection hashes','cell metadata matches actual model checkpoint hash','finite arrays and expected shapes','candidate indices and locked commands','endpoint/success recomputation','identical initial states and goals across methods and fits for each condition'],'files':checked}
(D/'integrity-audit.json').write_text(json.dumps(out,indent=2));print('Integrity verified:',len(checked),'cells; no effect estimates.')
