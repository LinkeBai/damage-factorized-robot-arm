"""Complete-grid paired report. Never publishes partial effect estimates."""
from pathlib import Path
import json,hashlib
import numpy as np
R=Path(__file__).resolve().parents[2];D=R/'runs/ipwm_validation_scale_calibration/planning_confirmation'
p=json.loads((D/'protocol.json').read_text());seeds=p['seeds'];methods=p['methods'];files={(s,m,l,b):D/f'seed{s}_{m}_D{l}_B{b}.npz' for s in seeds for m in methods for l in range(1,6) for b in range(2)}
missing=[v.name for v in files.values() if not v.exists() or not v.with_suffix('.json').exists()]
status={'expected_cells':len(files),'complete_cells':len(files)-len(missing),'missing':missing,'effects_released':False}
(D/'analysis-completeness.json').write_text(json.dumps(status,indent=2))
if missing:
 print(f'Incomplete: {len(files)-len(missing)}/{len(files)} cells. No effect report emitted.');raise SystemExit(0)
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
assert sha(R/'work/experiment_revision/confirm_scale_planning.py')==p['script_sha256']
for path,h in p['selection_hashes'].items():assert sha(R/path)==h
arrays={};references={}
for (seed,method,lock,band),path in files.items():
 with np.load(path) as z:
  assert z['states'].shape==(6,120,14),(path,z['states'].shape)
  for key in ['states','goals','endpoint','commands']:assert np.isfinite(z[key]).all(),(path,key)
  assert np.allclose(z['endpoint'],np.linalg.norm(z['states'][-1,:,10:12]-z['goals'],axis=1),rtol=1e-6,atol=1e-9)
  assert np.array_equal(z['success'],z['endpoint']<.03)
  key=(lock,band)
  if key not in references:references[key]=(z['states'][0].copy(),z['goals'].copy())
  assert np.array_equal(references[key][0],z['states'][0]) and np.array_equal(references[key][1],z['goals']),path
  arrays[(seed,method,lock,band)]=(z['endpoint'].copy()*1000,z['success'].astype(float)*100)
# Paired resampling within each of ten design cells; same indices for every fit.
rng=np.random.default_rng(914001);idx=np.concatenate([rng.integers(0,120,(2000,120))+120*i for i in range(10)],axis=1)
def joined(seed,method,k):return np.concatenate([arrays[(seed,method,l,b)][k] for l in range(1,6) for b in range(2)])
rows=[]
for baseline in ['original','carrier','global']:
 diffs=[];success=[]
 for seed in seeds:
  delta=joined(seed,baseline,0)-joined(seed,'calibrated',0);gain=joined(seed,'calibrated',1)-joined(seed,baseline,1)
  diffs.append(delta);success.append(gain)
  rows.append({'baseline':baseline,'seed':seed,'endpoint_reduction_mm':float(delta.mean()),'endpoint_conditional_95ci_mm':np.quantile(delta[idx].mean(1),[.025,.975]).tolist(),'success_gain_pp':float(gain.mean()),'success_conditional_95ci_pp':np.quantile(gain[idx].mean(1),[.025,.975]).tolist()})
 delta=np.mean(diffs,axis=0);gain=np.mean(success,axis=0)
 rows.append({'baseline':baseline,'seed':'mean_of_six_fits','endpoint_reduction_mm':float(delta.mean()),'endpoint_conditional_95ci_mm':np.quantile(delta[idx].mean(1),[.025,.975]).tolist(),'success_gain_pp':float(gain.mean()),'success_conditional_95ci_pp':np.quantile(gain[idx].mean(1),[.025,.975]).tolist()})
conditions=[{'seed':s,'method':m,'lock':l,'band':b,'endpoint_mm':float(v[0].mean()),'success_percent':float(v[1].mean())} for (s,m,l,b),v in arrays.items()]
method_summary=[]
for method in methods:
 endpoints=np.array([joined(seed,method,0).mean() for seed in seeds])
 successes=np.array([joined(seed,method,1).mean() for seed in seeds])
 method_summary.append({'method':method,'endpoint_mean_mm':float(endpoints.mean()),'endpoint_fit_sample_sd_mm':float(endpoints.std(ddof=1)),'success_mean_percent':float(successes.mean()),'success_fit_sample_sd_pp':float(successes.std(ddof=1))})
report={'inference':'1200 unique shared problems, six adaptation fits from shared foundation. Stratified paired problem bootstrap with 2000 resamples is conditional on these fits, not six independent pretraining runs. Report all seeds and cells. Analysis implementation written during the run, not claimed prospectively frozen before any observations.','protocol_sha256':sha(D/'protocol.json'),'rows':rows,'conditions':conditions,'method_summary':method_summary}
(D/'paired-analysis.json').write_text(json.dumps(report,indent=2))
status['effects_released']=True
status['report']='paired-analysis.json'
status['report_sha256']=sha(D/'paired-analysis.json')
(D/'analysis-completeness.json').write_text(json.dumps(status,indent=2))
print('Complete grid verified; paired-analysis.json written.')
