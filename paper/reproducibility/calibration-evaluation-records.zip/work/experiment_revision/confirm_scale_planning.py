"""Frozen fresh closed-loop comparison; calibration never changes here."""
from pathlib import Path
import sys,json,hashlib,time
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R),str(R/'src'),str(R/'scripts')]
import numpy as np
import torch,mujoco
from scripts.ipwm_scale_planning import state,select
from scripts.ipwm_scale_data import make_model,PROFILES
from scripts.ipwm_scale_train import build,OUT
from scripts.generate_primary_sequence_candidates import JOINTS,CONTACT_QPOS
D=R/'runs/ipwm_validation_scale_calibration';C=D/'planning_confirmation'
SEEDS=[7,17,27,37,47,57]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def setup(lock,band):
 ms=[];ds=[];goals=[]
 for i in range(120):
  rng=np.random.default_rng(np.random.SeedSequence([913406,lock,band,i]))
  m,eq=make_model(lock,PROFILES[i%4]);d=mujoco.MjData(m)
  q=CONTACT_QPOS+rng.normal(0,.015,5);v=rng.normal(0,.01,5);v[lock]=0
  for j,name in enumerate(JOINTS):d.qpos[m.joint(name).qposadr[0]]=q[j];d.qvel[m.joint(name).dofadr[0]]=v[j]
  for name in ['block_x','block_y']:d.qpos[m.joint(name).qposadr[0]]=rng.uniform(-.004,.004)
  m.eq_data[eq,0]=q[lock];mujoco.mj_forward(m,d)
  distance=rng.uniform(*((.04,.065) if band==0 else (.065,.09)));theta=rng.uniform(-np.pi/4,np.pi/4)
  goals.append(d.body('block').xpos[:2]+distance*np.array([np.cos(theta),np.sin(theta)]));ms.append(m);ds.append(d)
 return ms,ds,np.asarray(goals)
def main():
 torch.set_num_threads(4);C.mkdir(exist_ok=True)
 selections=[D/f'seed{s}/selection.json' for s in SEEDS];assert all(p.exists() for p in selections)
 spec=dict(seeds=SEEDS,methods=['original','calibrated','global','carrier'],problems=1200,locks=5,bands=[[.04,.065],[.065,.09]],problems_per_cell=120,candidates=128,replans=5,execute_steps=10,predict_steps=50,reset_namespace=913406,candidate_namespace=913407,primary='paired final endpoint distance, positive reduction favors calibrated',secondary='success under30mm; report every seed and condition',rule='all five replans, no favorable early stopping, same starts/goals/candidate draws per paired method; no calibration changes after results',selection_hashes={str(p.relative_to(R)):sha(p) for p in selections},script_sha256=sha(Path(__file__)))
 p=C/'protocol.json'
 if p.exists():assert json.loads(p.read_text())==spec
 else:p.write_text(json.dumps(spec,indent=2))
 for seed in SEEDS:
  for method in spec['methods']:
   family=method if method in ['global','carrier'] else 'ipwm'
   path=D/f'seed{seed}/model.pt' if method=='calibrated' else OUT/f'training/{family}/seed{seed}/model.pt'
   model=build(family,seed,'cuda');model.load_state_dict(torch.load(path,map_location='cuda',weights_only=True));model.eval()
   for lock in range(5):
    for band in range(2):
     dest=C/f'seed{seed}_{method}_D{lock+1}_B{band}.npz'
     if dest.exists():continue
     ms,ds,goals=setup(lock,band);initial=np.stack([state(m,d) for m,d in zip(ms,ds)]);states=[initial];chosen=[];commands=[];began=time.time()
     for step in range(5):
      rng=np.random.default_rng(np.random.SeedSequence([913407,seed,lock,band,step]))
      candidates=rng.uniform(-.8,.8,(120,128,5,5)).astype(np.float32);candidates[:,:,:,lock]=0
      pick=select(model,states[-1],candidates,goals,lock,initial[:,lock]);action=candidates[np.arange(120),pick,0]
      for m,d,u in zip(ms,ds,action):d.ctrl[:]=u;mujoco.mj_step(m,d,nstep=10);mujoco.mj_forward(m,d)
      states.append(np.stack([state(m,d) for m,d in zip(ms,ds)]));chosen.append(pick);commands.append(action)
     endpoint=np.linalg.norm(states[-1][:,10:12]-goals,axis=1)
     np.savez_compressed(dest,states=np.asarray(states),goals=goals,choices=np.asarray(chosen),commands=np.asarray(commands),endpoint=endpoint,success=endpoint<.03)
     dest.with_suffix('.json').write_text(json.dumps(dict(seed=seed,method=method,lock=lock+1,band=band,model_sha256=sha(path),seconds=time.time()-began,mean_endpoint=float(endpoint.mean()))))
     print(seed,method,lock+1,band,float(endpoint.mean()),flush=True)
if __name__=='__main__':main()
