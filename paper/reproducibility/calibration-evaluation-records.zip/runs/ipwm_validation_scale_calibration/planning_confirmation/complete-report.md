# Complete closed-loop confirmation

1200 unique shared problems, six adaptation fits from shared foundation. Stratified paired problem bootstrap with 2000 resamples is conditional on these fits, not six independent pretraining runs. Report all seeds and cells. Analysis implementation written during the run, not claimed prospectively frozen before any observations.

| Baseline | Fit | Endpoint reduction (mm) | Conditional 95% interval | Success gain (pp) |
|---|---|---:|---|---:|
| original | 7 | 0.000 | [0.000, 0.000] | 0.00 |
| original | 17 | 1.400 | [0.912, 1.911] | 1.50 |
| original | 27 | 0.695 | [0.230, 1.160] | 1.50 |
| original | 37 | 0.981 | [0.440, 1.558] | 2.50 |
| original | 47 | 0.000 | [0.000, 0.000] | 0.00 |
| original | 57 | 0.114 | [-0.418, 0.637] | -0.92 |
| original | mean_of_six_fits | 0.532 | [0.357, 0.712] | 0.76 |
| carrier | 7 | 3.636 | [2.946, 4.319] | 4.00 |
| carrier | 17 | 2.929 | [2.266, 3.570] | 2.25 |
| carrier | 27 | 6.405 | [5.727, 7.091] | 9.83 |
| carrier | 37 | 2.820 | [2.162, 3.491] | 3.83 |
| carrier | 47 | 1.328 | [0.634, 2.000] | -0.25 |
| carrier | 57 | 3.270 | [2.610, 3.993] | 3.75 |
| carrier | mean_of_six_fits | 3.398 | [3.085, 3.710] | 3.90 |
| global | 7 | -2.010 | [-2.588, -1.441] | -1.92 |
| global | 17 | 1.164 | [0.647, 1.668] | 1.17 |
| global | 27 | 0.810 | [0.234, 1.376] | 1.75 |
| global | 37 | -1.467 | [-2.090, -0.815] | -2.25 |
| global | 47 | -2.813 | [-3.418, -2.209] | -5.50 |
| global | 57 | -0.976 | [-1.611, -0.390] | -3.00 |
| global | mean_of_six_fits | -0.882 | [-1.126, -0.632] | -1.63 |

Positive values favor calibrated predictions. This report does not by itself attribute a change to state isolation or establish hardware gains. Full condition data are in paired-analysis.json.